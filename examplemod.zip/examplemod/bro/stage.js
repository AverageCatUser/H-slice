/* Stage layout for this mod, made with the E editor in H-Slice.
   Keep it in the mod's folder beside mod.js; it loads automatically.
   To change it, press E in game, arrange, then S to save a new one. */
HSLICE.stage("basement", {
  bf:  { x: 1157, y: 865, scale: 1.273 },
  gf:  { x: 397, y: 495, scale: 1 },
  dad: { x: -428, y: 450, scale: 1.033 },
  bg:  { image: "bg", x: -1019, y: -303, scale: 2.786 },
});
